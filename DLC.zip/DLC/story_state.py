opener = False
death = 1
